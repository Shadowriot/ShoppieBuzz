import React from 'react';
import './App.css';
import Registration from './registration.js';
function App() {
  return (
    <div>
      <Registration />
    </div>
  );
}

export default App;

import React from 'react';
import './registration.css';

const Registration = () => {
    return(
       
            <div classname='upper_part'>
                <h1 style={{color: 'red'}}>REGISTRATION</h1>
                <p>
                    lorem ipsum d
                </p>
            </div>
            
       
    );
};

export default Registration;
